package com.upeu.categoria.dto;

import lombok.Data;

@Data
public class CategoriaDTO {

    private Long id;

    private String nombre;

    private String imagen;
}